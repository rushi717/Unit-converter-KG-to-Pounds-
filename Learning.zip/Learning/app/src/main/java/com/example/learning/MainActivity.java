package com.example.learning;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button submit;
    private EditText getweight;
    private TextView see;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getweight=findViewById(R.id.getw);
        see=findViewById(R.id.see);
        submit=findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String val=getweight.getText().toString();
                int value=Integer.parseInt(val);
                double pounds=2.205*value;
                see.setText("Weight in pounds is "+pounds+" lbs");
                Toast.makeText(MainActivity.this,"Converted successfully ",Toast.LENGTH_SHORT).show();
            }
        });
    }
}